﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace JByfield_NHSBSA
{
    public class PageDateOfBirth
    {
        public PageDateOfBirth()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects  

        [FindsBy(How = How.Id, Using = "question-heading")]
        public IWebElement QuestionHeading;

        [FindsBy(How = How.Id, Using = "dob-day")]
        public IWebElement DOBDay;

        [FindsBy(How = How.Id, Using = "dob-month")]
        public IWebElement DOBMonth;

        [FindsBy(How = How.Id, Using = "dob-year")]
        public IWebElement DOBYear;

        [FindsBy(How = How.Id, Using = "next-button")]
        public IWebElement NextButton; 

        //Test Methods

        public void WaitUntilPageLoaded()
        {
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(NextButton));
        }

        public void AssertQuestion()
        {
            Assert.AreEqual("What is your date of birth?", QuestionHeading.Text);
        }

        public void FillInDOB()
        {
            DOBDay.Clear();
            DOBDay.SendKeys("10");

            DOBMonth.Clear(); 
            DOBMonth.SendKeys("01");

            DOBYear.Clear();
            DOBYear.SendKeys("1990");
        }

        public void ClickNext()
        {
            NextButton.Click(); 
        }

    }
}
