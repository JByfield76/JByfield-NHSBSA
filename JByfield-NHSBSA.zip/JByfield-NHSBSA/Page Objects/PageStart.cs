﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace JByfield_NHSBSA
{
    public class PageStart
    {
        public PageStart()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.XPath, Using = "/html/body/main/div[2]/form/div/div[1]/h1")]
        public IWebElement Title;

        [FindsBy(How = How.Id, Using = "next-button")]
        public IWebElement NextButton;

        //Test Methods
        public void WaitUntilPageLoaded()
        {
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(NextButton));
        }

        public void AssertTitle()
        {
            Assert.AreEqual("Check what help you could get to pay for NHS costs", Title.Text);
        }

        public void ClickNext()
        {
            NextButton.Click(); 
        }

    }
}
