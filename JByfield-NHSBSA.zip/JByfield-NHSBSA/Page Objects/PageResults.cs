﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace JByfield_NHSBSA
{
    public class PageResults
    {
        public PageResults()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "result-heading")]
        public IWebElement ResultHeader;

        [FindsBy(How = How.XPath, Using = "/html/body/main/div[2]/div/span/li")]
        public IWebElement ResultDetail;

        //test methods

        public void WaitUntilPageLoaded()
        {
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.PresenceOfAllElementsLocatedBy(By.Id("result-heading")));
        }

        public void AssertResults()
        {
            Assert.AreEqual("Based on what you've told us\r\nYou get help with NHS costs", ResultHeader.Text);
            Assert.AreEqual("If your prescription is dispensed in Wales or you have an Entitlement Card", ResultDetail.Text);
        }
    
    }
}
