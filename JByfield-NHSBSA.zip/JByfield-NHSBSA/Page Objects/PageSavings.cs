﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace JByfield_NHSBSA
{
    public class PageSavings
    {
        public PageSavings()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }
        
        //page objects 

        [FindsBy(How = How.Id, Using = "question-heading")]
        public IWebElement QuestionHeading;

        [FindsBy(How = How.Id, Using = "label-yes")]
        public IWebElement RadioYes;

        [FindsBy(How = How.Id, Using = "label-no")]
        public IWebElement RadioNo;

        [FindsBy(How = How.Id, Using = "next-button")]
        public IWebElement NextButton;

        //test methods 

        public void WaitUntilPageLoaded()
        {
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(NextButton));
        }

        public void AssertQuestion()
        {
            Assert.AreEqual("Do you have more than £16,000 in savings, investments or property?", QuestionHeading.Text);
        }

        public void SelectHasMoreThan16KSavings()
        {
            RadioYes.Click();
        }

        public void ClickNext()
        {
            NextButton.Click();
        }
    }
}


