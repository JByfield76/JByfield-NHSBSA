﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace JByfield_NHSBSA
{
    class Test001 : Hooks
    {
        public Test001() : base(
            (BrowserType)Enum.Parse(typeof(BrowserType),
                TestContext.Parameters["BrowserType"].ToString()),
                TestContext.Parameters["Url"].ToString())
        { }

        [Test]

        public void Test001Method()
        {
            //Loads up front page takes place in hooks, waits for it to load
            // asserts the title in the page, then clicks next
            Page.PageStart.WaitUntilPageLoaded();
            Page.PageStart.AssertTitle();
            Page.PageStart.ClickNext();

            //waits for page to load, asserts the question title 
            //selects Wales then clicks next
            Page.PageSelectCountry.WaitUntilPageLoaded();
            Page.PageSelectCountry.AssertQuestion();
            Page.PageSelectCountry.SelectWales();
            Page.PageSelectCountry.ClickNext();

            //waits for page to load, asserts the question title
            //add in the date of birth and then clicks next
            Page.PageDateOfBirth.WaitUntilPageLoaded();
            Page.PageDateOfBirth.AssertQuestion();
            Page.PageDateOfBirth.FillInDOB();
            Page.PageDateOfBirth.ClickNext();

            //waits for page to load, asserts the question title
            //selects no partner and then clicks next
            Page.PagePartner.WaitUntilPageLoaded();
            Page.PagePartner.AssertQuestion();
            Page.PagePartner.SelectNoPartner();
            Page.PagePartner.ClickNext();

            //waits for page to load, asserts the question title
            //selects no tax or benefits and then clicks next
            Page.PageTaxBenefits.WaitUntilPageLoaded();
            Page.PageTaxBenefits.AssertQuestion();
            Page.PageTaxBenefits.SelectClaimNoBenefits();
            Page.PageTaxBenefits.ClickNext();

            //waits for page to load, asserts the question title
            //selects not been pregnant or given birth and then clicks next
            Page.PagePregnant.WaitUntilPageLoaded();
            Page.PagePregnant.AssertQuestion();
            Page.PagePregnant.SelectNoPregnancy();
            Page.PagePregnant.ClickNext();

            //waits for page to load, asserts the question title
            //selects no injury and then clicks next
            Page.PageInjuryArmedForces.WaitUntilPageLoaded();
            Page.PageInjuryArmedForces.AssertQuestion();
            Page.PageInjuryArmedForces.SelectNoInjury();
            Page.PageInjuryArmedForces.ClickNext();

            //waits for page to load, asserts the question title
            //selects no diabetes and then clicks next
            Page.PageDiabetes.WaitUntilPageLoaded();
            Page.PageDiabetes.AssertQuestion();
            Page.PageDiabetes.SelectNoDiabetes();
            Page.PageDiabetes.ClickNext();

            //waits for page to load, asserts the question title
            //selects no diabetes and then clicks next
            Page.PageGlaucoma.WaitUntilPageLoaded();
            Page.PageGlaucoma.AssertQuestion();
            Page.PageGlaucoma.SelectNoGlaucoma();
            Page.PageGlaucoma.ClickNext();

            //waits for page to load, asserts the question title
            //selects not living in a care home and then clicks next
            Page.PageCareHome.WaitUntilPageLoaded();
            Page.PageCareHome.AssertQuestion();
            Page.PageCareHome.SelectNotLivingInCareHome();
            Page.PageCareHome.ClickNext();

            //waits for page to load, asserts the question title
            //selects do have more than £16,000 savings and then clicks next
            Page.PageSavings.WaitUntilPageLoaded();
            Page.PageSavings.AssertQuestion();
            Page.PageSavings.SelectHasMoreThan16KSavings();
            Page.PageSavings.ClickNext();

            //waits for page to load, asserts the results
            Page.PageResults.WaitUntilPageLoaded();
            Page.PageResults.AssertResults(); 

            Thread.Sleep(5000);

        }
    }
}
