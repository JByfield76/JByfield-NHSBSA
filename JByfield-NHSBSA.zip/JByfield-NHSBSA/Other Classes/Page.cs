﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace JByfield_NHSBSA
{
    public class Page
    {
        private static T GetPage<T>() where T : new()
        {
            var page = new T();
            PageFactory.InitElements(Base.WebDriver, page);
            return page;
        }

        public static PageStart PageStart
        {
            get { return GetPage<PageStart>(); }
        }

        public static PageSelectCountry PageSelectCountry
        {
            get { return GetPage<PageSelectCountry>(); }
        }

        public static PageDateOfBirth PageDateOfBirth
        {
            get { return GetPage<PageDateOfBirth>(); }
        }

        public static PagePartner PagePartner
        {
            get { return GetPage<PagePartner>(); }
        }

        public static PageTaxBenefits PageTaxBenefits
        {
            get { return GetPage<PageTaxBenefits>(); }
        }

        public static PagePregnant PagePregnant
        {
            get { return GetPage<PagePregnant>(); }
        }

        public static PageInjuryArmedForces PageInjuryArmedForces
        {
            get { return GetPage<PageInjuryArmedForces>(); }
        }

        public static PageDiabetes PageDiabetes
        {
            get { return GetPage<PageDiabetes>(); }
        }

        public static PageGlaucoma PageGlaucoma
        {
            get { return GetPage<PageGlaucoma>(); }
        }

        public static PageCareHome PageCareHome
        {
            get { return GetPage<PageCareHome>(); }
        }

        public static PageSavings PageSavings
        {
            get { return GetPage<PageSavings>(); }
        }

        public static PageResults PageResults
        {
            get { return GetPage<PageResults>(); }
        }

    }
}
