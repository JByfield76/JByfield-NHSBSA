﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace JByfield_NHSBSA
{
    public class Base
    {
        public static IWebDriver WebDriver { get; set; }
        public static WebDriverWait Wait { get; set; }
        public static IAlert Alert { get; set; }

    }
}
